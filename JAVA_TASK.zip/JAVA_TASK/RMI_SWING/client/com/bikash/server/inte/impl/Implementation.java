package com.bikash.server.inte.impl;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Vector;

import javax.swing.JTable;
import javax.xml.datatype.DatatypeConstants.Field;

import com.bikash.server.inte.Interface;
import com.mysql.jdbc.PreparedStatement;


public class Implementation extends UnicastRemoteObject implements Interface{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
//	private static Connection conn;
	private static String URL = "jdbc:mysql://localhost:3306/mini_project";
	private static String USER ="root";
	private static String PASS = "";
	//private JTable tblDetail = new JTable();
	public Implementation() throws RemoteException{
		super();
	}

	// Database connection
	public Connection connection() throws RemoteException {
		Connection conn = null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded succesfully");
			conn= DriverManager.getConnection(URL,USER,PASS);
			System.out.println("Database connected successfully....");
		}catch(Exception e){
			System.out.println(e);
		}
		return conn;
	}
	//insert code
	public int insert(String name, String address, String email, String contact) throws RemoteException {
		int row = 0;
		Connection c = null;
		Statement stmt = null;
		String sql = "";
		try{
			c= connection();
			stmt = c.createStatement();
			sql = "INSERT into employee (name,address,email,contact) VALUES ('"+name+"','"+address+"','"+email+"','"+contact+"')";

			row = stmt.executeUpdate(sql);

		}catch(Exception e){
			System.out.println("Insert error"+e);
		}
		return row;
	}


	//display code
	public Vector<Object> display() throws RemoteException {
		Connection c = null;
		Statement stmt = null;
		ResultSet rs = null;
		Vector<Object> val=new Vector<>(); 
		try{
			c= connection();
			stmt = c.createStatement();
			rs = stmt.executeQuery( "Select * from employee");
			while(rs.next()){
				Vector<Object> re=new Vector<>();
				re.add(rs.getInt("id"));
				re.add(rs.getString("name"));
				re.add(rs.getString("address"));
				re.add(rs.getString("email"));
				re.add(rs.getString("Contact"));
			   val.add(re);
			}
			
			return val ;
		}catch(Exception er){
			System.out.println("Display problem"+er);
		}
		return null;
	
	}

	public void delete(int s) throws RemoteException, SQLException {
		int row = 0;
		Connection c = null;
		Statement stmt = null;
		String sql = "";

		try {
			c = connection();
			stmt = c.createStatement();
			sql = "delete from employee where id='"+s+"'";
			row = stmt.executeUpdate(sql);
		}catch(Exception e){
			System.out.println(e);
		

		
	}
	}

	@Override
	public void updateData(String s) throws RemoteException {
			int row = 0;
			Connection c = null;
			Statement stmt = null;
			String sql = "";

			try {
				c = connection();
				stmt = c.createStatement();
				sql = "update employee set where id='"+s+"'";
				row = stmt.executeUpdate(sql);
			}catch(Exception e){
				System.out.println(e);
			

			
		}
		}
		
	}
	

	
	

	


