package com.bikash.server.inte;

import java.lang.reflect.Field;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public interface Interface extends Remote {
	public  Connection connection() throws RemoteException;
	public int insert(String name,String address,String email,String contact) throws RemoteException;
	public  Vector<Object> display() throws RemoteException;
	public void delete(int s) throws RemoteException, SQLException;
	public void updateData(String id) throws RemoteException;

	
}
