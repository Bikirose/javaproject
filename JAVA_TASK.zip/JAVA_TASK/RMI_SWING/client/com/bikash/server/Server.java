package com.bikash.server;
import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

import com.bikash.server.inte.impl.Implementation;
public class Server {
	public static void main(String[] args) {
		try{
			
			Implementation ic = new Implementation();
			LocateRegistry.createRegistry(1099);
			System.out.println("Registry created!");
			Naming.rebind("localhost/biki", ic);
			System.out.println("Rebinded succesfully");
		}catch(Exception e){
		System.out.println(e);
		}
	}

}
