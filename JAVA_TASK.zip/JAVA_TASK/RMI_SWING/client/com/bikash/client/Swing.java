package com.bikash.client;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Vector;
import java.awt.image.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

import com.bikash.server.inte.Interface;
public class Swing extends JFrame{


	//*************** DECLARING GLOBAL VARIABLES *******************//


	private JFrame frame = new JFrame();
	private JPanel panel = new JPanel();
	private JLabel labelform= new JLabel();
	private JLabel labeldisplay = new JLabel();
	private JLabel labelname= new JLabel();
	private JTextField txtname = new JTextField();
	private JLabel labeladdress = new JLabel();
	private JTextField txtaddress =new JTextField();
	private JLabel labelemail = new JLabel();
	private JTextField txtemail = new JTextField();
	private JLabel labelcontact = new JLabel();
	private JTextField txtcontact = new JTextField();
	private JButton insert = new JButton();
	private JButton delete = new JButton();
	private JButton update = new JButton();
	private JTable table = new JTable();
	private JPanel panelone = new JPanel();
	private Vector<Object> tbl_header = new Vector<>();
	private JScrollPane pane = new JScrollPane();


	//************** ASSIGNING VALUES WITH CONSTRUCTOS ********************//

	Swing(){
		frame = new JFrame("RMI SWING");
		frame.setLayout(null);
		panel.setLayout(null);
		frame.setSize(1000, 1000);
		frame.getContentPane().setBackground(Color.gray);
		labelname= new JLabel("Name");
		labeladdress= new JLabel("Address");
		labelemail= new JLabel("Email");
		labelcontact= new JLabel("Contact");
		txtname = new JTextField();
		txtaddress = new JTextField();
		txtemail = new JTextField();
		txtcontact = new JTextField();
		labelform = new JLabel("USER INFORMATION FORM");
		labeldisplay = new JLabel("Simple CRUP Operation Using Swing through RMI       By Bikash Rai");
		insert = new JButton("Insert");
		delete = new JButton("Delete");
		update = new JButton("Update");

		//************* SETTING BOUNDS ****************************//

		panel.setBounds(20, 100, 500, 500);
		panel.setBackground(Color.green);

		panelone.setBounds(530, 100, 700, 500);
		panelone.setBackground(Color.CYAN);
		labelname.setBounds(30,60,50,30);
		labeladdress.setBounds(30,110,50,30);
		labelemail.setBounds(30,160,50,30);
		labelcontact.setBounds(30,210,50,30);
		labelform.setBounds(50,10,250,30);
		labelform.setFont(new Font("Arial", Font.BOLD, 16));
		labelform.setForeground(Color.red);
		labeldisplay.setBounds(200,20,1000,30);
		labeldisplay.setForeground(Color.WHITE);
		labeldisplay.setFont(new Font("Arial", Font.BOLD, 20));
		txtname.setBounds(100,60,180,30);
		txtaddress.setBounds(100,110,180,30);
		txtemail.setBounds(100,160,180,30);
		txtcontact.setBounds(100,210,180,30);
		insert.setBounds(100,260,80,30);
		delete.setBounds(700,800,80,30);
		update.setBounds(700,850,80,30);


		//******************* ADDING TO THE FRAME AND PANELS******************************//

		frame.add(panel);
		frame.add(labeldisplay);
		panel.add(txtname);
		panel.add(txtaddress);
		panel.add(txtemail);
		panel.add(txtcontact);
		panel.add(insert);
		panel.add(labelname);
		panel.add(labeladdress);
		panel.add(labelemail);
		panel.add(labelcontact);
		panel.add(labelform);


		// ********** INSERT *****************//

		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub

				String name = txtname.getText();
				String address = txtaddress.getText();
				String email = txtemail.getText();
				String contact = txtcontact.getText();
				int result = 0;
				try{
					Interface i = (Interface)Naming.lookup("localhost/biki");
					result = i.insert(name, address, email, contact);
					if(result>0){
						JOptionPane.showMessageDialog(null," Inserted!!");
					}
					else{
						JOptionPane.showMessageDialog(null, "Could not insert");
					}

				}catch(Exception e){
					System.out.println(e);
				}

			}
		});


		// ****** POPULLATING DATA FROM DB AND DISPLAY IN TABLE ************//
		
		//I want put this code in display() method so that i can call right after inserting data and deleting data  
		
		tbl_header.addElement("ID");
		tbl_header.addElement("Name");
		tbl_header.addElement("Address");
		tbl_header.addElement("Email");
		tbl_header.addElement("Contact");
		try{
			Interface i = (Interface)Naming.lookup("localhost/biki");
			Vector<Object> eee =new Vector<>(i.display());
			table = new JTable(eee , tbl_header);
			table.setMaximumSize(new Dimension(700,200));
			table.setRowHeight(40);
			table.getColumnModel().getColumn(0).setPreferredWidth(50);
			table.getColumnModel().getColumn(1).setPreferredWidth(90);
			table.getColumnModel().getColumn(2).setPreferredWidth(90);
			table.getColumnModel().getColumn(3).setPreferredWidth(130);
			table.setSelectionMode(0);
			pane = new JScrollPane(table);
			pane.setPreferredSize(new Dimension(500, 400));
			table.setFont(new Font("Arial", Font.BOLD, 12));
			panelone.add(pane);
			frame.add(panelone);
			panelone.add(delete);
			panelone.add(update);
		}catch(Exception e){
			System.out.println(e);
		}
		update.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				
				// I WANT TO UPDATE DATA AFTER PRESSING IN UPDATE BUTTON
				//UPDATE METHOD IS IN REMOTE
				
			}
		});

		//***********   DELETE   ****************//

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try{
					Interface i = (Interface)Naming.lookup("localhost/biki");
					int row = table.getSelectedRow();
					int s=Integer.parseInt(table.getValueAt(row, 0).toString());
					i.delete(s);
					JOptionPane.showMessageDialog(null, "Deleted !!");
				}catch(Exception e3){
					System.out.println(e3);
				}
			}
		});
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	

	public static void main(String[] args) {
		new Swing();
	}

}
